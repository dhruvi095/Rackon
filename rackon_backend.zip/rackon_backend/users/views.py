from rest_framework import generics, permissions, status
from .serializers import UserSerializer, CustomTokenObtainPairSerializer
from .models import User
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.response import Response


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    
# Custom login view
class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer    

class ProfileImageUploadView(generics.UpdateAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user

    def patch(self, request, *args, **kwargs):
        """Upload/replace profile image"""
        return super().partial_update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        """Remove/reset profile image"""
        user = self.get_object()
        if user.profile_image:
            user.profile_image.delete(save=False)  # remove from storage
            user.profile_image = None              # reset field
            user.save(update_fields=["profile_image"])
            return Response({"detail": "Profile image removed."}, status=status.HTTP_200_OK)
        return Response({"detail": "No profile image to remove."}, status=status.HTTP_400_BAD_REQUEST)